import { LightningElement } from 'lwc';

export default class CssInLwc extends LightningElement {}